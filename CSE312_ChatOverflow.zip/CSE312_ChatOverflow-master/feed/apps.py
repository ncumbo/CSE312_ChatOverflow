from django.apps import AppConfig


class FeedConfig(AppConfig):
    name = 'feed'

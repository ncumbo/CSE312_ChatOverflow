from django.contrib import admin
from .models import Post

# Register your models here to show up on admin page
#admin.site.register(Post)
